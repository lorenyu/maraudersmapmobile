#ifndef LOCATIONREQUESTOR_H
#define LOCATIONREQUESTOR_H

//  INCLUDES
#include <lbs.h>
#include <LbsSatellite.h>

/*class TPositionInfo;
class TPositionSatelliteInfo;*/
class CLocationRequestor;

class CLocationUpdater : public CActive {

    public:
        CLocationUpdater();

        void ConstructL(CLocationRequestor *locationRequestor, PyObject* callback);

        virtual ~CLocationUpdater();

        void Stop();

        void RunL();

        void DoCancel();

        void SetLocationCallback(PyObject *callback);

        void SafeCancel();

    private:
        void InvokeLocationCallback(PyObject *arg);

        PyObject *iLocationCallback;
        CLocationRequestor *iLocationRequestor;
        TThreadId iOwnerThreadId;
};

/**
*  Position requestor.
*  Request the position from the MLFW and
*  handles the position requesting process
*/
class CLocationRequestor
{
    public: //Construction and destruction

        static CLocationRequestor* NewL() ;

        void SetUpdateOptionsL(TInt updateInterval, TInt updateTimeout, TInt maxAge, bool allowPartial);
        void OpenL(TInt moduleId);
        void Close();
        bool IsStarted();
        void setRequestor(TDesC& requestor);
        void InstallPositionCallbackL(PyObject* callback);

        TInt getDefaultModuleId();
        TInt getNumModules();
        PyObject* getModuleInfoByIndex(TInt moduleIndex);
        PyObject* getModuleInfoById(TInt moduleId);
        PyObject* getLastKnownPositionL();
        PyObject* getModuleStatus(TInt moduleId);
        PyObject* notifyPositionUpdateL();
        PyObject* getSatelliteData(int index);

        TPositionInfoBase& GetPositionInfoBase();
        PyObject* processResultL(TRequestStatus& iStatus, bool doLastKnown, bool nestedTuple);
        RPositioner* GetPositioner();

        /**
        * Destructor.
        */
        virtual ~CLocationRequestor();

    protected:  // Functions from base classes


    private:  // New Functions
        /**
        * By default Symbian 2nd phase constructor is private.
        */
        void ConstructL( );

        CLocationRequestor();

        PyObject* loopLocationL(bool doLastKnown);

        /**
        * Starts a position requesting sequence
        */
        void DoInitialiseL();

        /**
        * Gets the name of the positioning module. If the name is not
        * available the name will be an empty string
        * @param   aModuleId The id of the module
        */
        void GetModuleName(const TPositionModuleId& aModuleId);

        TInt64 toStandardTime(TTime time);
        TReal32 toKmPerHour(TReal32 mPerS);
        PyObject* createModuleInfoResult(TInt err, TPositionModuleInfo positionModuleInfo);

        /**
        * Pre process the position information
        */
        PyObject* ShowErrorL(TInt error, const TDesC& aErrorString, bool nestedTuple);
        PyObject* PositionInfoUpdatedL(TPositionInfoBase& aPosInfo,  const TDesC& aModulename, bool isPartial, bool nestedTuple);
        PyObject* PositionUpdatedL(bool isPartial, bool nestedTuple);
        
    private:    // Data

        //The id of the currently used PSY
		TPositionModuleId iUsedPsy;

        // Position server
        RPositionServer iPosServer;

        // Positioner
        RPositioner iPositioner;

        // Basic location info
        TPositionInfo iPositionInfo;

        // Satellite info
        TPositionSatelliteInfo iSatelliteInfo;

        // Module name
        TBuf<KPositionMaxModuleName> iModuleName;

        // The id of the used psy
        TPositionUpdateOptions iUpdateops;

        // Position info base
        TPositionInfoBase& iPosInfoBase;

        bool iStarted;

        TDesC iRequestor;

        CLocationUpdater* iLocationUpdater;
};
#endif //LOCATIONREQUESTOR_H
// End of File
