import e32

if e32.s60_version_info>=(3,0):
    import imp
    _locationrequestor=imp.load_dynamic('_locationrequestor', 'c:\\sys\\bin\\_locationrequestor.pyd')
    del imp
	
else:
    import _locationrequestor

del e32 #remove unnecessary names from namespace
from _locationrequestor import *
del _locationrequestor

ETechnologyUnknown      = 0;
ETechnologyTerminal     = 0x01;
ETechnologyNetwork      = 0x02;
ETechnologyAssisted     = 0x04;

EDeviceUnknown  = 0;
EDeviceInternal = 0x01;
EDeviceExternal = 0x02;

ECapabilityNone        = 0;
ECapabilityHorizontal  = 0x0001;
ECapabilityVertical    = 0x0002;
ECapabilitySpeed       = 0x0004;
ECapabilityDirection   = 0x0008;
ECapabilitySatellite   = 0x0010;
ECapabilityCompass     = 0x0020;
ECapabilityNmea        = 0x0040;
ECapabilityAddress     = 0x0080;
ECapabilityBuilding    = 0x0100;
ECapabilityMedia       = 0x0200;

ECostUnknown = 0;
ECostZero = 1;
ECostPossible = 2;
ECostCharge = 3;

EPowerUnknown = 0;
EPowerZero = 1;
EPowerLow = 2;
EPowerMedium = 3;
EPowerHigh = 4;

#EDeviceUnknown = 0;
EDeviceError = 1;
EDeviceDisabled = 2;
EDeviceInactive = 3;
EDeviceInitialising = 4;
EDeviceStandBy = 5;
EDeviceReady = 6;
EDeviceActive = 7;

EDataQualityUnknown = 0;
EDataQualityLoss = 1;
EDataQualityPartial = 2;
EDataQualityNormal = 3;


