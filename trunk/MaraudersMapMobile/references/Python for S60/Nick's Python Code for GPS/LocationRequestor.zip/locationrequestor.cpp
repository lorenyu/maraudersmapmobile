#include <e32std.h>
#include <e32base.h>
#include <EIKBTGPC.H>
#include <avkon.hrh>
#include <aknnavi.h>
#include <aknnavide.h>
#include <eikspane.h>
#include <aknappui.h>
#include <lbs.h>
#include <LbsSatellite.h>
#ifdef EKA2
#include <csatelliteinfoui.h> 
#endif

#include "Python.h"
#include "symbian_python_ext_util.h"

// INCLUDE FILES
#include "locationrequestor.h"
#include "logger.h"

// PYTHON STUFF
#define RETURN_PYNONE \
  Py_INCREF(Py_None);\
  return Py_None;

#define requestor_type_string "locationrequestor.LocationRequestorType"

#define type_LocationRequestor (*(PyTypeObject *)SPyGetGlobalString(requestor_type_string))


// type-definition
typedef struct
{
    PyObject_HEAD;
	CLocationRequestor* iLocationRequestor;
} obj_LocationRequestor;

static PyObject* locationrequestor_ShowSatelliteDialog(PyObject* /*self*/, PyObject* args)
{
#ifdef EKA2
	char* req;
	int reqLen;

	if (PyArg_ParseTuple(args, "u#:ShowSatelliteDialog", &req, &reqLen))
    {
        TPtrC req_desc((TUint16*)req, reqLen);
        int err;
	    Py_BEGIN_ALLOW_THREADS
	    TRAP(err, {
	      	CSatelliteInfoUI* dlg = CSatelliteInfoUI::NewL();
			dlg->ExecuteLD(req_desc);
	    });
	    Py_END_ALLOW_THREADS

	    RETURN_ERROR_OR_PYNONE(err);
	}
	return 0;
#else
    RETURN_PYNONE
#endif
}

// ctor (factory-function)
static PyObject* locationrequestor_LocationRequestor(PyObject* /*self*/, PyObject* /*args*/)
{
    obj_LocationRequestor *requestor = PyObject_New(obj_LocationRequestor, &type_LocationRequestor);

    if (!requestor)
    {
        return 0;
    }

    TRAPD(err,
        requestor->iLocationRequestor = CLocationRequestor::NewL();
    );

    if (err)
    {
        PyObject_Del(requestor);
        return SPyErr_SetFromSymbianOSErr(err);
    }

    return (PyObject*)requestor;
}

// dtor
static void dealloc_LocationRequestor(obj_LocationRequestor* requestor)
{
	delete requestor->iLocationRequestor;
    PyObject_Del(requestor);
}


static const PyMethodDef locationrequestor_methods[] =
{
    {"LocationRequestor", (PyCFunction)locationrequestor_LocationRequestor, METH_NOARGS},
	{"ShowSatelliteDialog", (PyCFunction)locationrequestor_ShowSatelliteDialog, METH_VARARGS},
	{0, 0} /* sentinel */
};

static PyObject* LocationRequestor_setUpdateOptions(obj_LocationRequestor* self, PyObject * args)
{
	TInt updateInterval;
	TInt updateTimeout;
	TInt maxAge;
	TInt allowPartial;
	if (PyArg_ParseTuple(args, "iiii:SetUpdateOptions", &updateInterval, &updateTimeout, &maxAge, &allowPartial)) {
		// check if timeout and interval are ok
        if (updateInterval < 0) {
            PyErr_SetString(PyExc_TypeError, "update interval must be >= 0");
            return 0;
        }
        if (updateTimeout < 0) {
            PyErr_SetString(PyExc_TypeError, "update timeout must be >= 0");
            return 0;
        }
        if (maxAge < 0) {
            PyErr_SetString(PyExc_TypeError, "update timeout must be >= 0");
            return 0;
        }
        if (maxAge > updateInterval) {
            PyErr_SetString(PyExc_TypeError, "update interval must be larger than maximum age");
            return 0;
        }
        if (updateInterval > updateTimeout) {
            PyErr_SetString(PyExc_TypeError, "update interval must be smaller than update timeout");
            return 0;
        }
        TRAPD(err,
        	 self->iLocationRequestor->SetUpdateOptionsL(updateInterval, updateTimeout, maxAge, allowPartial != 0);
        );

        RETURN_ERROR_OR_PYNONE(err);
	}
	return 0;
}

static PyObject* LocationRequestor_open(obj_LocationRequestor* self, PyObject * args)
{
	TInt moduleId;
	if (PyArg_ParseTuple(args, "i:Open", &moduleId)) {

        if (self->iLocationRequestor->IsStarted()) {
            // close previous session
    		TRAPD(err,
                self->iLocationRequestor->Close();
    		);

    		if (err)
			{
                return SPyErr_SetFromSymbianOSErr(err);
			}
        }
        TRAPD(err,
            self->iLocationRequestor->OpenL(moduleId);
        );

		RETURN_ERROR_OR_PYNONE(err);
	}
	return 0;
}

static PyObject* LocationRequestor_close(obj_LocationRequestor* self, PyObject* /*args*/) {
	TRAPD(err,
		self->iLocationRequestor->Close();
	);
    RETURN_ERROR_OR_PYNONE(err);
}

static PyObject* LocationRequestor_getDefaultModuleId(obj_LocationRequestor* self, PyObject* /*args*/)
{
    TInt result = self->iLocationRequestor->getDefaultModuleId();
    return Py_BuildValue("i", result);
}

static PyObject* LocationRequestor_getNumModules(obj_LocationRequestor* self, PyObject* /*args*/)
{
    TInt result = self->iLocationRequestor->getNumModules();
    return Py_BuildValue("i", result);
}

static PyObject* LocationRequestor_getModuleInfoByIndex(obj_LocationRequestor* self, PyObject* args)
{
	TInt moduleIndex;
	if (PyArg_ParseTuple(args, "i:GetModuleInfoByIndex", &moduleIndex))
    {
		  return self->iLocationRequestor->getModuleInfoByIndex(moduleIndex);
	}
    return 0;
}

static PyObject* LocationRequestor_getModuleInfoById(obj_LocationRequestor* self, PyObject* args)
{
	TInt moduleId;
	if (PyArg_ParseTuple(args, "i:GetModuleInfoById", &moduleId))
    {
		  return self->iLocationRequestor->getModuleInfoById(moduleId);
	}
    return 0;
}

static PyObject* LocationRequestor_setRequestor(obj_LocationRequestor* self, PyObject* args)
{
	char* req;
	int reqLen;

	if (PyArg_ParseTuple(args, "u#:SetRequestor", &req, &reqLen))
    {
        TPtrC req_desc((TUint16*)req, reqLen);
		self->iLocationRequestor->setRequestor(req_desc);

		RETURN_PYNONE
	}
    return 0;
}

static PyObject* LocationRequestor_getModuleStatus(obj_LocationRequestor* self, PyObject* args)
{
	TInt moduleId;
	if (PyArg_ParseTuple(args, "i:GetModuleStatus", &moduleId)) {
        return self->iLocationRequestor->getModuleStatus(moduleId);
	}
    return 0;
}

static PyObject* LocationRequestor_notifyPositionUpdate(obj_LocationRequestor* self, PyObject* /*args*/) {
	PyObject* result = NULL;
	TRAPD(err,
		result = self->iLocationRequestor->notifyPositionUpdateL();
	);
	if (result)
	{
		return result;
	}
    RETURN_ERROR_OR_PYNONE(err);
}

CLocationUpdater::CLocationUpdater():CActive(EPriorityStandard)
{
    CActiveScheduler::Add(this);
    RThread t;
    iOwnerThreadId = t.Id();
}
  
void CLocationUpdater::ConstructL(CLocationRequestor *locationRequestor, PyObject* callback) {
    iLocationRequestor = locationRequestor;
    SetLocationCallback(callback);
    iLocationRequestor->GetPositioner()->NotifyPositionUpdate(iLocationRequestor->GetPositionInfoBase(), iStatus);
    SetActive();
}

CLocationUpdater::~CLocationUpdater()
{
    Py_XDECREF(iLocationCallback); 
    iLocationCallback = NULL;
}    
  
  /* Stop the current operation, if any. If a completion callback has
     been set, DECREF it. */
void CLocationUpdater::Stop()
{
    SafeCancel(); // DoCancel sets the proper state.
    // Note that this can indirectly cause this object to be destroyed!
    Py_XDECREF(iLocationCallback);
    iLocationCallback = NULL;
}

void CLocationUpdater::SafeCancel()
{
    RThread t;
    if (iOwnerThreadId == t.Id())
    {
    	TRAPD(err,
        	Cancel();
        );
    }
}

void CLocationUpdater::RunL()
{
    // if iStatus == KErrCancel then we may be in a different thread? Anyway, don't do anything in the cancel case
    if (iStatus != KErrCancel) {
        PyEval_RestoreThread(PYTHON_TLS->thread_state);
        PyObject* args = iLocationRequestor->processResultL(iStatus, true, true);
        if (args != NULL)
        {
            InvokeLocationCallback(args);
        }
        PyEval_SaveThread();
    	iLocationRequestor->GetPositioner()->NotifyPositionUpdate(iLocationRequestor->GetPositionInfoBase(), iStatus);
    	SetActive();
    }
}
  
void CLocationUpdater::DoCancel()
{
    iLocationRequestor->GetPositioner()->CancelRequest(EPositionerNotifyPositionUpdate);
}

void CLocationUpdater::SetLocationCallback(PyObject *callback)
{
    Py_XDECREF(iLocationCallback);
    iLocationCallback = callback;
    Py_XINCREF(callback);
}  
  
void CLocationUpdater::InvokeLocationCallback(PyObject *arg)
{
    if (iLocationCallback) {
        PyObject* rval = PyEval_CallObject(iLocationCallback, (PyObject*)arg);
        Py_XDECREF(rval);
    }
    Py_XDECREF(arg);
}

static PyObject* LocationRequestor_installPositionCallback(obj_LocationRequestor* self, PyObject* args) {
    PyObject* callback = NULL;
    if (!PyArg_ParseTuple(args, "O:InstallPositionCallback", &callback)) 
        return NULL;  

    if (!PyCallable_Check(callback))
	{
        PyErr_SetString(PyExc_TypeError, "Callback must be a callable method");
	    return NULL;
	}

    TRAPD(error,
        self->iLocationRequestor->InstallPositionCallbackL(callback);
    );
    RETURN_ERROR_OR_PYNONE(error);
}

static PyObject* LocationRequestor_getLastKnownPosition(obj_LocationRequestor* self, PyObject* /*args*/) {
	PyObject* result = NULL;
	TRAPD(err,
		result = self->iLocationRequestor->getLastKnownPositionL();
	);
	if (result)
	{
		return result;
	}
    RETURN_ERROR_OR_PYNONE(err);
}

static PyObject* LocationRequestor_getSatelliteData(obj_LocationRequestor* self, PyObject* args) {
    int index;
    if (!PyArg_ParseTuple(args, "i:GetSatelliteData", &index)) 
        return NULL;  

    return self->iLocationRequestor->getSatelliteData(index);
}

static const PyMethodDef LocationRequestor_methods[] =
{
    {"SetRequestor", (PyCFunction)LocationRequestor_setRequestor, METH_VARARGS, "void SetRequestor(string requestor)"},
    {"Open", (PyCFunction)LocationRequestor_open, METH_VARARGS, "void Open(int moduleId)"},
    {"Close", (PyCFunction)LocationRequestor_close, METH_NOARGS, "void Close()" },
    {"GetDefaultModuleId", (PyCFunction)LocationRequestor_getDefaultModuleId, METH_NOARGS, "int GetDefaultModuleId()" },
    {"GetNumModules", (PyCFunction)LocationRequestor_getNumModules, METH_NOARGS, "int GetNumModules()"},
    {"GetModuleInfoByIndex", (PyCFunction)LocationRequestor_getModuleInfoByIndex, METH_VARARGS, "(uid, name, technologyType, deviceLocation, capabilities, secondsToFirstFix, secondsToNextFix, horAccuracy, verAccuracy, costIndicator, powerConsumption GetModuleInfoByIndex(int index)" },
    {"GetModuleInfoById", (PyCFunction)LocationRequestor_getModuleInfoById, METH_VARARGS, "(uid, name, technologyType, deviceLocation, capabilities, secondsToFirstFix, secondsToNextFix, horAccuracy, verAccuracy, costIndicator, powerConsumption GetModuleInfoById(int id)"},
    {"GetModuleStatus", (PyCFunction)LocationRequestor_getModuleStatus, METH_VARARGS, "(deviceStatus, dataQualityStatus) GetModuleStatus(int id)" },
    {"SetUpdateOptions", (PyCFunction)LocationRequestor_setUpdateOptions, METH_VARARGS, "void SetUpdateOptions(updateInterval, updateTimeout, maxAge, allowPartial)" },
    {"NotifyPositionUpdate" , (PyCFunction)LocationRequestor_notifyPositionUpdate , METH_NOARGS, "(isPartial, latitude, longitude, altitude, horAccuracy, verAccuracy, modulename, time [, speedKmH, speedAccuracyKmH, heading, headingAccuracy, satelliteTime, numSatInView, numSatUsed [, SatelliteData]]) NotifyPositionUpdate()"},
    {"GetLastKnownPosition", (PyCFunction)LocationRequestor_getLastKnownPosition, METH_NOARGS, "(isPartial, latitude, longitude, altitude, horAccuracy, verAccuracy, modulename, time [, speedKmH, speedAccuracyKmH, heading, headingAccuracy, satelliteTime, numSatInView, numSatUsed [, SatelliteData]]) GetLastKnownPosition()"},
    {"InstallPositionCallback" , (PyCFunction)LocationRequestor_installPositionCallback , METH_VARARGS, "void InstallPositionCallback(callback)"},
    {"GetSatelliteData" , (PyCFunction)LocationRequestor_getSatelliteData , METH_VARARGS, "(id, azimuth, elevation, signalstrength, isused) GetSatelliteData(index)"},
    {NULL, NULL} /* sentinel */
};

static PyObject *getattr_LocationRequestor(PyObject *self, char *name)
{
    return Py_FindMethod(const_cast<PyMethodDef*>(&LocationRequestor_methods[0]), self, name);
}

static const PyTypeObject type_template_LocationRequestor =
{
/*******************************************************/
    PyObject_HEAD_INIT(0)    /* initialize to 0 to ensure Win32 portability */
    0,                 /*ob_size*/
    "locationrequestor.LocationRequestor",            /*tp_name*/
    sizeof(obj_LocationRequestor), /*tp_basicsize*/
    0,                 /*tp_itemsize*/
    /* methods */
    (destructor)dealloc_LocationRequestor, /*tp_dealloc*/
	 0, /*tp_print*/
    (getattrfunc)getattr_LocationRequestor, /*tp_getattr*/

    /* implied by ISO C: all zeros thereafter */
};

DL_EXPORT(void) init_locationrequestor()
{
	Py_InitModule("_locationrequestor", (PyMethodDef*) locationrequestor_methods);

	PyTypeObject *locationrequestorTypeObject = PyObject_New(PyTypeObject, &PyType_Type);
	if (!locationrequestorTypeObject) return;

    *locationrequestorTypeObject = type_template_LocationRequestor;

	TInt err = SPyAddGlobalString(requestor_type_string, (PyObject *)locationrequestorTypeObject);
    if (0 != err) // 0 is success
	{
        PyObject_Del(locationrequestorTypeObject);
   		PyErr_SetString(PyExc_Exception, "SPyAddGlobalString failed");
        return;
	}

    // notice that the this uses the macro defined in the beginning of file
    type_LocationRequestor.ob_type = &PyType_Type;
}

// C++ STUFF

// CONSTANTS

//Second
const TInt KSecond = 1000000;

// Unknown string used when module name is not known
_LIT(KUnknown,"Unknown");

//The name of the requestor
_LIT(KRequestor,"Python Extension");

_LIT(KSatStatus, "Satellite Ref");

//Error messages
_LIT(KQualityErr,"Position request completed with KPositionQualityLoss");
_LIT(KAccessErr,"Access denied! Check privacy settings");
_LIT(KTimedoutErr,"Location request timed out");
_LIT(KCanceledErr,"Location request canceled");
_LIT(KNotStartedErr,"Error: not started.");

// ============================ MEMBER FUNCTIONS ===============================

// -----------------------------------------------------------------------------
// CLocationRequestor::CLocationRequestor
// C++ default constructor can NOT contain any code, that
// might leave.
// -----------------------------------------------------------------------------
//
CLocationRequestor::CLocationRequestor()
    : iPosInfoBase( iSatelliteInfo ),
      iRequestor( KRequestor ),
      iLocationUpdater( NULL)

{
}

void CLocationRequestor::Close()
{
    if (iStarted)
    {
		TRAPD(err,
	       	// shut down updater thread (if any)
	        if (iLocationUpdater != NULL) {
	            iLocationUpdater->SafeCancel();
	            iLocationUpdater = NULL;
	        }
	        // Close the positioner
	        iPositioner.Close();
	    );
        iStarted = false;
    }
}

// -----------------------------------------------------------------------------
// CLocationRequestor::ConstructL
// Symbian 2nd phase constructor can leave.
// -----------------------------------------------------------------------------
//
void CLocationRequestor::ConstructL()
{
    // Initialise the position request sequence
    DoInitialiseL();
}

// -----------------------------------------------------------------------------
// CLocationRequestor::NewL
// Two-phased constructor.
// -----------------------------------------------------------------------------
//
CLocationRequestor* CLocationRequestor::NewL()
{
    //Create the object
    CLocationRequestor* self = new( ELeave ) CLocationRequestor();

    //Push to the cleanup stack
    CleanupStack::PushL( self );

    //Construct the object
    self->ConstructL();

    //Remove from cleanup stack
    CleanupStack::Pop( self );

    //Return pointer to the created object
    return self;
}

// -----------------------------------------------------------------------------
// CLocationRequestor::~CLocationRequestor
// Destructor
// -----------------------------------------------------------------------------
//
CLocationRequestor::~CLocationRequestor()
{
	TRAPD(err,
	    // Close the positioner
	    if (iStarted) Close();

	    // Close the session to the position server
	    iPosServer.Close();
	);
}

void CLocationRequestor::InstallPositionCallbackL(PyObject* callback)
{
    CLocationUpdater* updater = new (ELeave)CLocationUpdater();
    CleanupStack::PushL(updater);
    updater->ConstructL(this, callback);
    CleanupStack::Pop();

    iLocationUpdater = updater;
}    

PyObject* CLocationRequestor::loopLocationL(bool doLastKnown)
{
    TRequestStatus iStatus;
	if (doLastKnown)
    {
        iPositioner.GetLastKnownPosition( iPosInfoBase, iStatus );
    }
    else
    {
		iPositioner.NotifyPositionUpdate( iPosInfoBase, iStatus );
    }
	while (true)
    {
		User::WaitForRequest(iStatus);
		PyObject* result = processResultL(iStatus, doLastKnown, false);
		if (result != NULL) return result;
    }
}


PyObject* CLocationRequestor::processResultL(TRequestStatus& iStatus, bool doLastKnown, bool nestedTuple)
{
    switch ( iStatus.Int() )
    {
        // The fix is valid
        case KErrNone:
        // The fix has only partially valid information.
        // It is guaranteed to only have a valid timestamp
        case KPositionPartialUpdate:
            {
                // Pre process the position information
                return PositionUpdatedL(iStatus == KPositionPartialUpdate, nestedTuple);
            }
        // The data class used was not supported
        case KErrArgument:
            {
                // Set info base to position info
                iPosInfoBase = iPositionInfo;

                if (!nestedTuple) {
                     // Request next position
                	if (doLastKnown)
                    {
                        iPositioner.GetLastKnownPosition( iPosInfoBase, iStatus );
                    }
                    else
                    {
                		iPositioner.NotifyPositionUpdate( iPosInfoBase, iStatus );
                    }
                }
    			return NULL;
            }
        // The position data could not be delivered
        case KPositionQualityLoss:
            {
                // Send error to position listener
                return ShowErrorL(iStatus.Int(), KQualityErr, nestedTuple);
            }
        // Access is denied
        case KErrAccessDenied:
            {
                // Send stopped to position listener
                return ShowErrorL(iStatus.Int(), KAccessErr, nestedTuple);
            }
        // Request timed out
        case KErrTimedOut:
            {
                // Send error to position listener
                return ShowErrorL(iStatus.Int(), KTimedoutErr, nestedTuple);
            }
        // The request was canceled
        case KErrCancel:
            {
                // Send stopped to position listener
                return ShowErrorL(iStatus.Int(), KCanceledErr, nestedTuple);
            }
        // There is no last known position
        case KErrUnknown:
            {
                return ShowErrorL(iStatus.Int(), KCanceledErr, nestedTuple);
            }
        // Unrecovable errors.
        default:
            {
                // Send stopped to position listener
                return ShowErrorL(iStatus.Int(), KCanceledErr, nestedTuple);
            }
    }
}

PyObject* CLocationRequestor::notifyPositionUpdateL()
{
    if (!iStarted)
    {
        return ShowErrorL(0, KNotStartedErr, false);
    }

    return loopLocationL(false);
}

PyObject* CLocationRequestor::getLastKnownPositionL()
{
    return loopLocationL(true);
}

PyObject* CLocationRequestor::getSatelliteData(int index)
{
    if (iPosInfoBase.PositionClassType() & EPositionSatelliteInfoClass)
    {
        // sat info
        TSatelliteData satData;
        TPositionSatelliteInfo* posInfo = STATIC_CAST(TPositionSatelliteInfo*, &iPosInfoBase);
        int err = posInfo->GetSatelliteData(index, satData);
        if (err)
        {
            return SPyErr_SetFromSymbianOSErr(err);
        }

        return Py_BuildValue("(iddii)", satData.SatelliteId(), satData.Azimuth(), satData.Elevation(), satData.SignalStrength(), satData.IsUsed());
    }
    else
    {
        // no sat info
        RETURN_PYNONE
    }
}


PyObject* CLocationRequestor::getModuleStatus(TInt moduleId)
{
    TPositionModuleStatus status;
    TInt err = iPosServer.GetModuleStatus(status, TUid::Uid(moduleId));
    if (err != KErrNone)
    {
        return SPyErr_SetFromSymbianOSErr(err);
    }
    return Py_BuildValue("(ii)",
                status.DeviceStatus(),
                status.DataQualityStatus()
            );
}

void CLocationRequestor::DoInitialiseL()
{
    // Connect to the position server
    TInt error = iPosServer.Connect( );

    // The connection failed
    if ( KErrNone != error )
    {
        // leave
        User::Leave(error);
    }
    iStarted = false;
}

bool CLocationRequestor::IsStarted()
{
    return iStarted;
}

TPositionInfoBase& CLocationRequestor::GetPositionInfoBase()
{
    return iPosInfoBase;
}

RPositioner* CLocationRequestor::GetPositioner()
{
    return &iPositioner;
}

TInt CLocationRequestor::getDefaultModuleId()
{
    TPositionModuleId id;
    iPosServer.GetDefaultModuleId(id);
    return id.iUid;
}

TInt CLocationRequestor::getNumModules()
{
    TUint id;
    iPosServer.GetNumModules(id);
    return id;
}

PyObject* CLocationRequestor::createModuleInfoResult(TInt err, TPositionModuleInfo positionModuleInfo)
{
    if (err != KErrNone)
    {
        return SPyErr_SetFromSymbianOSErr(err);
    }

    TBuf<KPositionMaxModuleName> moduleName;
    positionModuleInfo.GetModuleName(moduleName);

    TPositionQuality positionQuality;
    positionModuleInfo.GetPositionQuality(positionQuality);

    return Py_BuildValue("(iu#iiiLLddii)",
                  positionModuleInfo.ModuleId().iUid,
                  moduleName.Ptr(),
                  moduleName.Length(),
                  positionModuleInfo.TechnologyType(),
                  positionModuleInfo.DeviceLocation(),
                  positionModuleInfo.Capabilities(),
                  positionQuality.TimeToFirstFix().Int64() / KSecond,
                  positionQuality.TimeToNextFix().Int64() / KSecond,
                  positionQuality.HorizontalAccuracy(),
                  positionQuality.VerticalAccuracy(),
                  positionQuality.CostIndicator(),
                  positionQuality.PowerConsumption()
              );
}

PyObject* CLocationRequestor::getModuleInfoByIndex(TInt moduleIndex)
{
    TPositionModuleInfo positionModuleInfo;
    TInt err = iPosServer.GetModuleInfoByIndex(moduleIndex, positionModuleInfo);
    return createModuleInfoResult(err, positionModuleInfo);
}

PyObject* CLocationRequestor::getModuleInfoById(TInt moduleId)
{
    TPositionModuleInfo positionModuleInfo;
    TInt err = iPosServer.GetModuleInfoById(TUid::Uid(moduleId), positionModuleInfo);
    return createModuleInfoResult(err, positionModuleInfo);
}

void CLocationRequestor::SetUpdateOptionsL(TInt updateInterval, TInt updateTimeout, TInt maxAge, bool allowPartial)
{
    // Set update interval to one second to receive one position data per second
    iUpdateops.SetUpdateInterval(TTimeIntervalMicroSeconds(updateInterval * KSecond));

    // If position server could not get position
    // In two minutes it will terminate the position request
    iUpdateops.SetUpdateTimeOut(TTimeIntervalMicroSeconds(updateTimeout * KSecond));

    // Positions which have time stamp below maxAge can be reused
    iUpdateops.SetMaxUpdateAge(TTimeIntervalMicroSeconds(maxAge * KSecond));

    // Enables location framework to send partial position data
    iUpdateops.SetAcceptPartialUpdates(allowPartial);

    if (iStarted)
    {
        int error =  iPositioner.SetUpdateOptions( iUpdateops );

        // The options could not be updated
        if ( KErrNone != error )
        {
            // Show error to the user and leave
            User::Leave(error);
        }
    }
}

void CLocationRequestor::setRequestor(TDesC& requestor)
{
    iRequestor = requestor;
}

void CLocationRequestor::OpenL(TInt moduleId)
{
    int error;

    // Open subsession to the position server
    if (moduleId == -1)
    {
        error = iPositioner.Open(iPosServer);
    }
    else
    {
        error = iPositioner.Open(iPosServer, TUid::Uid(moduleId));
    }

    // The opening of a subsession failed
    if ( KErrNone != error )
    {
        // Show error to the user and leave
        User::Leave(error);
    }

    // Set position requestor
    error = iPositioner.SetRequestor( CRequestor::ERequestorService, CRequestor::EFormatApplication , iRequestor );

    // The requestor could not be set
    if ( KErrNone != error )
    {
        // Show error to the user and leave
        User::Leave(error);
    }

    // Set update options
    error =  iPositioner.SetUpdateOptions( iUpdateops );

    // The options could not be updated
    if ( KErrNone != error  )
    {
        // Show error to the user and leave
        User::Leave(error);
    }

    iStarted = true;
}

// -----------------------------------------------------------------------------
// CLocationRequestor::GetModuleName
// Gets the name of the positioning module by id.
// -----------------------------------------------------------------------------
//
void CLocationRequestor::GetModuleName(const TPositionModuleId& aModuleId)
{
    // Module information of the position module
    TPositionModuleInfo modInfo;

    // Get module info by module id
    TInt error = iPosServer.GetModuleInfoById( *&aModuleId, modInfo );

    // If error occured
    if ( KErrNone != error )
    {
        // Set the name of the module to 'Unknown'
        iModuleName = KUnknown;
    }
    else
    {
        // Get the name of the position module
        modInfo.GetModuleName(iModuleName);
    }
}

// -----------------------------------------------------------------------------
// CLocationRequestor::PositionUpdatedL
// Pre process the position information
// -----------------------------------------------------------------------------
//
PyObject* CLocationRequestor::PositionUpdatedL(bool isPartial, bool nestedTuple)
{
	// Check if the id of the used PSY is 0
	if ( 0 == iUsedPsy.iUid)
	{
        // Set the id of the currently used PSY
		iUsedPsy = iPosInfoBase.ModuleId();
	}
	// Check if the position module has changed
	else if ( iPosInfoBase.ModuleId() != iUsedPsy )
	{
		// Set the id of the currently used PSY
		iUsedPsy = iPosInfoBase.ModuleId();

		//Position module info of new module
		TPositionModuleInfo moduleInfo;

		// Get module info
		iPosServer.GetModuleInfoById(iUsedPsy,moduleInfo);

        // Get classes supported
        TInt32 moduleInfoFamily = moduleInfo.ClassesSupported(EPositionInfoFamily);

        iPosInfoBase = iSatelliteInfo;

		// Check if the new module supports
		// TPositionSatelliteInfo class
		if ( EPositionSatelliteInfoClass & moduleInfoFamily )
		{
			// Set info base to satellite info
			iPosInfoBase = iSatelliteInfo;
		}
        // The position module must support atleast
		// TPositionInfo class
        else
        {
            // Set info base to position info
			iPosInfoBase = iPositionInfo;
        }
	}
	else
	{
	// Do nothing
	}

    // Process the position information
	// and request next position

    // Get module name
    GetModuleName(iUsedPsy);

    // Send position information to registered listener
    return PositionInfoUpdatedL(iPosInfoBase, iModuleName, isPartial, nestedTuple);
}


PyObject* CLocationRequestor::PositionInfoUpdatedL(TPositionInfoBase& aPosInfo,
    const TDesC& aModulename, bool isPartial, bool nestedTuple)
{
	PyObject *arglist;

    /* Time to call the callback */
    // Check the type of the updated position information
    // and process that information.

    // Check if position information class type is TPositionSatelliteInfo
    if (aPosInfo.PositionClassType() & EPositionSatelliteInfoClass)
    {
        // Cast the TPositionInfoBase object to TPositionSatelliteInfo
        TPositionSatelliteInfo* posInfo = STATIC_CAST(TPositionSatelliteInfo*,&aPosInfo);

	    // Standard location information
	    TPosition position;

	    // Get basic position data
	    posInfo->GetPosition(position);

	    // The course info
	    TCourse course;

	    // Get the satellite info
	    posInfo->GetCourse(course);

        arglist = Py_BuildValue((char*)(nestedTuple?"((idddddu#LddddLii))":"(idddddu#LddddLii)"),
        		(TInt)isPartial,
        		position.Latitude(),
        		position.Longitude(),
        		position.Altitude(),
        		position.HorizontalAccuracy(),
        		position.VerticalAccuracy(),
        		aModulename.Ptr(),
        		aModulename.Length(),
        		toStandardTime(position.Time()),
        		toKmPerHour(course.Speed()),
        		toKmPerHour(course.SpeedAccuracy()),
        		course.Heading(),
        		course.HeadingAccuracy(),
        		toStandardTime(posInfo->SatelliteTime()),
        		posInfo->NumSatellitesInView(),
        		posInfo->NumSatellitesUsed()
    		);
    }
    // Check if position information class type is TPositionInfo
    else if (aPosInfo.PositionClassType() & EPositionInfoClass)
    {
        //Cast the TPositionInfoBase object to TPositionInfo
        TPositionInfo* posInfo =STATIC_CAST(TPositionInfo*,&aPosInfo);

	    // Standard location information
	    TPosition position;

	    // Get basic position data
	    posInfo->GetPosition(position);


	    arglist = Py_BuildValue((char*)(nestedTuple?"((idddddu#L))":"(idddddu#L)"),
	    		(TInt)isPartial,
	    		position.Latitude(),
	    		position.Longitude(),
	    		position.Altitude(),
	    		position.HorizontalAccuracy(),
	    		position.VerticalAccuracy(),
	    		aModulename.Ptr(),
	    		aModulename.Length(),
	    		toStandardTime(position.Time())
    		);
    }
    else
    {
        // Do nothing
	    arglist = Py_BuildValue("()");
    }

    return arglist;
}

TInt64 CLocationRequestor::toStandardTime(TTime time)
{
    TTimeIntervalMicroSeconds interval = time.MicroSecondsFrom(TTime(TDateTime(1970, EJanuary, 0, 0, 0, 0, 0)));

    // convert the microseconds value to milliseconds
    return (interval.Int64() / TInt64(1000));
}

TReal32 CLocationRequestor::toKmPerHour(TReal32 mPerS)
{
    if ( !Math::IsNaN(STATIC_CAST(TReal64,mPerS)) )
    {
        // Convert to km/h
        mPerS = (mPerS * 10) / 36;
    }
    return mPerS;
}

PyObject* CLocationRequestor::ShowErrorL(TInt error, const TDesC& aErrorString, bool nestedTuple)
{
    return Py_BuildValue((char*)(nestedTuple?"((iu#))":"(iu#)"),
    		error,
    		aErrorString.Ptr(),
    		aErrorString.Length()
		);
}

#ifndef EKA2
GLDEF_C TInt E32Dll(TDllReason)
{
	return KErrNone;
}
#endif
